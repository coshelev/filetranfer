#!/usr/bin/env python3
# -*- coding:utf8 -*-

import datetime
import json
from pymongo import MongoClient
from urllib.parse import unquote


def save_request(site_name, request_body):
    record = {}
    result = ''
    if site_name == 'calltouch':
        record_list = unquote(request_body).split('&')
        for item in record_list:
            pre_record = item.split('=')
            record[pre_record[0]] = pre_record[1]
    else:
        record = json.loads(request_body)
    try:
        mongo_client = MongoClient('localhost', 27017, username='webhook', password='P@ssw0rd', authSource='admin')
        mongo_db = mongo_client[site_name]

        db_posts = mongo_db['saved_' + str(datetime.date.today()).replace('-', '')]
        post_id = db_posts.insert_one(record).inserted_id
        result = 'saved in mongo {}'.format(post_id)
    except:
        result = 'Mongo Error'
    return result
