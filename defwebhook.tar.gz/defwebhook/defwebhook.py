#!/usr/bin/env python3
# -*- coding:utf8 -*-

import sys
from aiohttp import web
from suds.client import Client
from suds import WebFault
import app_logger
import mongoactions
from daemon import Daemon

logger = app_logger.get_logger(__name__)
site = {'avito': ['http://mainappl/asc_oper/ws/MatrixService?wsdl', 'AvitoEvent', ['save']],
        'autoru': ['http://mainappl/asc_oper/ws/MatrixService?wsdl', 'AutoruEvent', ['save']],
        'jivosite': ['http://mainappl/sys_agr/ws/SysAgrPublic?wsdl', 'JivositeEvent', ['save']],
        'leadgenic': ['http://mainappl/sys_agr/ws/SysAgrPublic?wsdl', 'LeadGenic', []],
        'livetex': ['http://mainappl/asc_oper/ws/MatrixService?wsdl', 'LiveTexEvent', []],
        'greenapi': ['http://mainappl/asc_oper/ws/MatrixService?wsdl', 'GreenApiWhatsappEvent', ['save']],
        'expertchat': ['http://mainappl/asc_oper/ws/MatrixService?wsdl', 'ExpertChat', ['save']],
        'mtsvpbx': ['', '', []],
        'calltouch': ['', '', ['save']]}


def send_event(site_name, data_for_send):  # Отправляем тело сообщения в 1С
    try:
        appl_client = Client(site[site_name][0])
        method_to_execute = getattr(appl_client.service, site[site_name][1])
        result = method_to_execute(data_for_send)
    except WebFault as detail:
        logger.error(detail)
        result = 'ERROR# ' + str(detail)
    except:
        logger.error(sys.exc_info())
        result = 'ERROR'
    return result


async def handle(request):
    text = 'Hello'
    name = request.match_info.get('name', '')
    if name == '':
        text = '{}, yopta...'.format(text)
    elif name in site.keys():
        text = '{}, {}, yopta...'.format(text, name)
    logger.info('GET Request: {}'.format(request.headers))
    return web.Response(text=text)


async def handle_post(request):
    status = 404
    site_name = request.match_info.get('site_name', '')
    if site_name in site.keys():
        status = 200
        # explicitly send the response
        resp = web.Response(status=status)
        await resp.prepare(request)
        await resp.write_eof()

        headers = request.headers
        logger.info('{}: {}'.format(site_name, headers))
        body = await request.text()
        logger.info('{}: {}'.format(site_name, body))
        if site[site_name][0] != '':
            result = send_event(site_name, body)
        else:
            result = 'Not for send'
        if 'save' in site[site_name][2]:
            result = '{} -> {}'.format(result, mongoactions.save_request(site_name, body))
        logger.info('{}: {}'.format(site_name, result))
    else:
        resp = web.Response(status=status)
        await resp.prepare(request)
    return resp  # web.Response(status=status, reason=None)


app = web.Application(middlewares=[web.normalize_path_middleware(append_slash=False, remove_slash=False, merge_slashes=True)])
app.add_routes([web.get('/', handle),
                web.get('/{name}', handle),
                web.get('/{name}/', handle),
                web.post('/{site_name}', handle_post),
                web.post('/{site_name}/', handle_post)])


class MyDaemon(Daemon):
    """
    description of class
    """
    def run(self):
        web.run_app(app)


if __name__ == '__main__':
    daemon = MyDaemon('/tmp/def_webhook.pid')
    if len(sys.argv) == 2:
        if 'start' == sys.argv[1]:
            daemon.start()
        elif 'stop' == sys.argv[1]:
            daemon.stop()
        elif 'restart' == sys.argv[1]:
            daemon.restart()
        else:
            print('Unknown command')
            sys.exit(2)
        sys.exit(0)
    else:
        print('usage: {0} start|stop|restart'.format(sys.argv[0]))
        sys.exit(2)
