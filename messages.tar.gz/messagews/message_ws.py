#!/usr/bin/env python3
# -*- coding:utf8 -*-

import datetime
import sys
import os
from pymongo import MongoClient
from bson.json_util import dumps
from ladon.ladonizer import ladonize
import app_logger


class message_ws(object):
    """
    This service ...
    - change_agent_state: activate or deactivate agent in queue and check minimum count of agents in queue
    - add_agent: add agent in queue
    - remove_agent: remove agent from all queues
    """
    logger = app_logger.get_logger(__name__)
    dirpath = os.path.dirname(__file__)

    @ladonize(str, str, rtype=str)
    def get_id_list(self, site_name, event_date=''):
        """
        :param site_name:
        :param event_date: str - 'YYYYMMDD'
        @rtype: list of messages id
        """

        ids = ''
        ids_list = []
        try:
            mongo_client = MongoClient('192.168.0.236', 27017, username='webhook', password='P@ssw0rd', authSource='admin')
            mongo_db = mongo_client[site_name]
            if event_date != '':
                posts_date = event_date
            else:
                posts_date = str(datetime.date.today()).replace('-', '')
            self.logger.info('{} {}'.format(site_name, posts_date))
            db_posts = mongo_db['saved_' + posts_date]
            if site_name == 'autoru':
                ids_list = db_posts.distinct('message.id')
            elif site_name == 'avito':
                ids_list = db_posts.distinct('messages.0.id')
            elif site_name == 'expertchat':
                ids_int_list = db_posts.distinct('messages.0.id')
                if len(ids_int_list):
                    ids_list = [str(int) for int in ids_int_list]
                else:
                    ids_list = []
            elif site_name == 'greenapi':
                ids_list = db_posts.distinct('idMessage')

            if len(ids_list):
                ids = ','.join(ids_list)

        except:
            self.logger.error(sys.exc_info())
        finally:
            return ids

    @ladonize(str, str, str, rtype=str)
    def get_message(self, site_name, ids, event_date=''):
        """
        :param site_name:
        :param ids:
        :param event_date: str - 'YYYYMMDD'
        @rtype: list of messages
        """
        messages_list = []
        ids_list = ids.split(',')
        try:
            mongo_client = MongoClient('192.168.0.236', 27017, username='webhook', password='P@ssw0rd', authSource='admin')
            mongo_db = mongo_client[site_name]
            if event_date != '':
                posts_date = event_date
            else:
                posts_date = str(datetime.date.today()).replace('-', '')
            db_posts = mongo_db['saved_' + posts_date]
            if site_name == 'autoru':
                messages_list = db_posts.find({'message.id': {'$in': ids_list}}, {'_id': 0})
            elif site_name == 'avito':
                messages_list = db_posts.find({'messages.0.id': {'$in': ids_list}}, {'_id': 0})
                # print(dumps(messages_list))
            elif site_name == 'expertchat':
                ids_int_list = [int(str) for str in ids_list]
                messages_list = db_posts.find({'messages.0.id': {'$in': ids_int_list}}, {'_id': 0})
            elif site_name == 'greenapi':
                messages_list = db_posts.find({'idMessage': {'$in': ids_list}}, {'_id': 0})

        except:
            self.logger.error(sys.exc_info())
        finally:
            return dumps(messages_list)
