#!/usr/bin/env python3
# -*- coding: utf8 -*-

from ladon.server.wsgi import LadonWSGIApplication
from os.path import abspath, dirname

application = LadonWSGIApplication(
    ['message_ws'],
    [dirname(abspath(__file__))],
    catalog_name='Webhook Messages webservice catalog',
    catalog_desc='root of Webhook Messages webservice catalog')
